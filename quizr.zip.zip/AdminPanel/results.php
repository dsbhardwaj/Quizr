<?php
include("admin_check.php");
include("../connection.php");

// Filters
$filter_subject = isset($_GET['subject']) ? (int)$_GET['subject'] : 0;
$search         = isset($_GET['q'])       ? trim($_GET['q'])       : '';

$where = "WHERE 1=1";
if ($filter_subject > 0) $where .= " AND r.subject_id = $filter_subject";
if ($search !== '') {
    $s     = mysqli_real_escape_string($data, $search);
    $where .= " AND (u.name LIKE '%$s%' OR s.name LIKE '%$s%')";
}

$sql = "
    SELECT r.*, u.name AS user_name, s.name AS subject_name
    FROM result r
    LEFT JOIN users u ON r.user_id = u.id
    LEFT JOIN subjects s ON r.subject_id = s.id
    $where
    ORDER BY r.id DESC
";
$result = mysqli_query($data, $sql);
$rows   = [];
while ($r = mysqli_fetch_assoc($result)) { $rows[] = $r; }

// Summary stats
$total_attempts  = count($rows);
$total_score     = array_sum(array_column($rows, 'score'));
$total_ques      = array_sum(array_column($rows, 'total_ques'));
$overall_avg     = $total_ques > 0 ? round(($total_score / $total_ques) * 100) : 0;

// Subjects for filter dropdown
$subj_res = mysqli_query($data, "SELECT * FROM subjects ORDER BY name ASC");
$subjects = [];
while ($s = mysqli_fetch_assoc($subj_res)) { $subjects[] = $s; }

$admin_name = $_SESSION['admin_username'] ?? 'Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Quiz Results — Quizr Admin</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
  <style>
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:#f5f6fa;color:#111110;min-height:100vh;}
    .navbar{display:flex;align-items:center;justify-content:space-between;padding:0 24px;height:56px;background:#fff;border-bottom:.5px solid rgba(0,0,0,.08);position:sticky;top:0;z-index:100;}
    .nav-left{display:flex;align-items:center;gap:10px;}
    .nav-logo{font-size:15px;font-weight:600;display:flex;align-items:center;gap:8px;text-decoration:none;color:#111110;}
    .nav-logo-dot{width:8px;height:8px;border-radius:50%;background:#1D9E75;}
    .admin-chip{background:#FAEEDA;color:#633806;border:.5px solid #FAC775;border-radius:100px;padding:2px 8px;font-size:11px;font-weight:600;}
    .nav-right{display:flex;align-items:center;gap:8px;}
    .nav-admin{font-size:13px;color:#6b6b6a;display:flex;align-items:center;gap:6px;}
    .nav-avatar{width:28px;height:28px;border-radius:50%;background:#E6F1FB;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;color:#0C447C;}
    .btn{display:inline-flex;align-items:center;gap:6px;padding:7px 14px;border-radius:8px;font-size:13px;font-weight:500;cursor:pointer;font-family:inherit;transition:all .12s;text-decoration:none;border:.5px solid rgba(0,0,0,.14);}
    .btn-ghost{background:transparent;color:#111110;}.btn-ghost:hover{background:#f0f0ef;}
    .btn-danger{background:#FCEBEB;color:#791F1F;border-color:#F7C1C1;}.btn-danger:hover{background:#F7C1C1;}
    .btn-sm{padding:5px 10px;font-size:12px;}
    .layout{display:grid;grid-template-columns:200px 1fr;min-height:calc(100vh - 56px);}
    .sidebar{background:#fff;border-right:.5px solid rgba(0,0,0,.08);padding:20px 12px;display:flex;flex-direction:column;gap:2px;}
    .sidebar-label{font-size:10px;font-weight:600;color:#9b9b9a;text-transform:uppercase;letter-spacing:.08em;padding:8px 10px 4px;}
    .sidebar-item{display:flex;align-items:center;gap:8px;padding:8px 10px;border-radius:8px;font-size:13px;color:#6b6b6a;text-decoration:none;border:none;background:transparent;font-family:inherit;width:100%;text-align:left;transition:all .12s;cursor:pointer;}
    .sidebar-item:hover{background:#f0f0ef;color:#111110;}.sidebar-item.active{background:#f0f0ef;color:#111110;font-weight:500;}
    .sidebar-item.danger{color:#A32D2D;}.sidebar-item.danger:hover{background:#FCEBEB;}
    .main{padding:28px 28px 56px;overflow:auto;}
    .page-header{display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:24px;}
    .page-title{font-size:20px;font-weight:600;letter-spacing:-.02em;}
    .page-sub{font-size:13px;color:#6b6b6a;margin-top:3px;}
    .stats-row{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:20px;}
    .stat-card{background:#fff;border:.5px solid rgba(0,0,0,.08);border-radius:12px;padding:16px 18px;display:flex;align-items:center;gap:14px;}
    .stat-icon{width:36px;height:36px;border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:17px;flex-shrink:0;}
    .stat-val{font-size:22px;font-weight:300;letter-spacing:-.02em;line-height:1;}
    .stat-lbl{font-size:12px;color:#6b6b6a;margin-top:3px;}
    .toolbar{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:16px;}
    .search-wrap{position:relative;flex:1;min-width:200px;max-width:300px;}
    .search-wrap i{position:absolute;left:10px;top:50%;transform:translateY(-50%);font-size:15px;color:#9b9b9a;pointer-events:none;}
    .search-wrap input{width:100%;padding:8px 12px 8px 32px;border:.5px solid rgba(0,0,0,.14);border-radius:8px;font-size:13px;font-family:inherit;background:#fff;color:#111110;outline:none;transition:border-color .15s,box-shadow .15s;}
    .search-wrap input:focus{border-color:#1D9E75;box-shadow:0 0 0 3px rgba(29,158,117,.12);}
    .search-wrap input::placeholder{color:#b0b0ae;}
    .select-filter{padding:8px 28px 8px 12px;border:.5px solid rgba(0,0,0,.14);border-radius:8px;font-size:13px;font-family:inherit;background:#fff;color:#111110;outline:none;appearance:none;cursor:pointer;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%239b9b9a' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 8px center;}
    .result-count{font-size:13px;color:#6b6b6a;margin-left:auto;}
    .result-count span{font-weight:600;color:#111110;}
    .table-card{background:#fff;border:.5px solid rgba(0,0,0,.08);border-radius:14px;overflow:hidden;}
    table{width:100%;border-collapse:collapse;}
    th{text-align:left;font-size:11px;font-weight:600;color:#6b6b6a;text-transform:uppercase;letter-spacing:.07em;padding:10px 18px;border-bottom:.5px solid rgba(0,0,0,.06);}
    td{padding:12px 18px;font-size:13px;border-bottom:.5px solid rgba(0,0,0,.05);vertical-align:middle;}
    tr:last-child td{border-bottom:none;}
    tbody tr:hover td{background:#fafaf9;}
    .user-cell{display:flex;align-items:center;gap:9px;}
    .user-avatar{width:30px;height:30px;border-radius:50%;background:#E1F5EE;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;color:#0F6E56;flex-shrink:0;}
    .subject-chip{display:inline-flex;align-items:center;gap:5px;padding:3px 9px;border-radius:6px;font-size:12px;background:#f0f0ef;color:#6b6b6a;font-weight:500;}
    .pct-badge{display:inline-flex;align-items:center;font-size:12px;font-weight:600;padding:3px 10px;border-radius:100px;}
    .badge-green{background:#EAF3DE;color:#27500A;}
    .badge-blue{background:#E6F1FB;color:#0C447C;}
    .badge-amber{background:#FAEEDA;color:#633806;}
    .badge-red{background:#FCEBEB;color:#791F1F;}
    .mini-bar-wrap{width:70px;height:4px;background:#f0f0ef;border-radius:2px;overflow:hidden;margin-top:4px;}
    .mini-bar-fill{height:100%;border-radius:2px;}
    .empty-state{padding:48px;text-align:center;color:#9b9b9a;font-size:14px;}
    .empty-state i{font-size:28px;display:block;margin-bottom:10px;color:#b0b0ae;}
    @media(max-width:900px){.stats-row{grid-template-columns:1fr 1fr;}}
    @media(max-width:640px){.layout{grid-template-columns:1fr;}.sidebar{display:none;}}
  </style>
</head>
<body>
<nav class="navbar">
  <div class="nav-left">
    <a class="nav-logo" href="admin_dashboard.php"><div class="nav-logo-dot"></div>Quizr</a>
    <span class="admin-chip">Admin</span>
  </div>
  <div class="nav-right">
    <div class="nav-admin">
      <div class="nav-avatar"><?php echo strtoupper(substr($admin_name,0,1)); ?></div>
      <?php echo htmlspecialchars($admin_name); ?>
    </div>
    <a class="btn btn-danger" href="admin_logout.php"><i class="ti ti-logout" style="font-size:14px;"></i> Logout</a>
  </div>
</nav>
<div class="layout">
  <aside class="sidebar">
    <div class="sidebar-label">Overview</div>
    <a class="sidebar-item" href="admin_dashboard.php"><i class="ti ti-layout-dashboard" style="font-size:15px;"></i> Dashboard</a>
    <div class="sidebar-label" style="margin-top:8px;">Content</div>
    <a class="sidebar-item" href="add_question.php"><i class="ti ti-circle-plus" style="font-size:15px;"></i> Add Question</a>
    <a class="sidebar-item" href="view_questions.php"><i class="ti ti-list-details" style="font-size:15px;"></i> View Questions</a>
    <div class="sidebar-label" style="margin-top:8px;">Management</div>
    <a class="sidebar-item" href="manage_users.php"><i class="ti ti-users" style="font-size:15px;"></i> Manage Users</a>
    <a class="sidebar-item" href="manage_subjects.php"><i class="ti ti-books" style="font-size:15px;"></i> Manage Subjects</a>
    <a class="sidebar-item active" href="results.php"><i class="ti ti-chart-bar" style="font-size:15px;"></i> View Results</a>
    <div class="sidebar-label" style="margin-top:8px;">Account</div>
    <a class="sidebar-item danger" href="admin_logout.php"><i class="ti ti-logout" style="font-size:15px;"></i> Logout</a>
  </aside>
  <main class="main">
    <div class="page-header">
      <div><div class="page-title">Quiz Results</div><div class="page-sub">All quiz attempt records across all users</div></div>
    </div>

    <div class="stats-row">
      <div class="stat-card">
        <div class="stat-icon" style="background:#E6F1FB;"><i class="ti ti-list-check" style="color:#0C447C;font-size:17px;"></i></div>
        <div><div class="stat-val"><?php echo $total_attempts; ?></div><div class="stat-lbl">Total attempts</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon" style="background:#EAF3DE;"><i class="ti ti-target" style="color:#27500A;font-size:17px;"></i></div>
        <div><div class="stat-val"><?php echo $overall_avg; ?>%</div><div class="stat-lbl">Overall avg. score</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon" style="background:#F3E8FF;"><i class="ti ti-books" style="color:#6B21A8;font-size:17px;"></i></div>
        <div><div class="stat-val"><?php echo count($subjects); ?></div><div class="stat-lbl">Subjects</div></div>
      </div>
    </div>

    <form method="GET" action="results.php">
      <div class="toolbar">
        <div class="search-wrap">
          <i class="ti ti-search"></i>
          <input type="text" name="q" placeholder="Search user or subject…" value="<?php echo htmlspecialchars($search); ?>">
        </div>
        <select name="subject" class="select-filter" onchange="this.form.submit()">
          <option value="0">All subjects</option>
          <?php foreach ($subjects as $s): ?>
            <option value="<?php echo $s['id']; ?>" <?php echo $filter_subject===(int)$s['id']?'selected':''; ?>>
              <?php echo htmlspecialchars($s['name']); ?>
            </option>
          <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-ghost btn-sm"><i class="ti ti-search" style="font-size:13px;"></i> Search</button>
        <?php if ($search || $filter_subject > 0): ?>
          <a class="btn btn-ghost btn-sm" href="results.php"><i class="ti ti-x" style="font-size:13px;"></i> Clear</a>
        <?php endif; ?>
        <div class="result-count"><span><?php echo $total_attempts; ?></span> record<?php echo $total_attempts!=1?'s':''; ?></div>
      </div>
    </form>

    <div class="table-card">
      <?php if (!empty($rows)): ?>
      <table>
        <thead>
          <tr>
            <th style="width:44px;">ID</th>
            <th>User</th>
            <th>Subject</th>
            <th style="width:90px;">Score</th>
            <th style="width:120px;">Percentage</th>
            <th style="width:140px;">Submitted on</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $r):
            $pct = $r['total_ques'] > 0 ? round(($r['score']/$r['total_ques'])*100, 2) : 0;
            if      ($pct >= 80) { $cls = 'pct-badge badge-green'; $bar = '#1D9E75'; }
            elseif  ($pct >= 60) { $cls = 'pct-badge badge-blue';  $bar = '#3B82F6'; }
            elseif  ($pct >= 40) { $cls = 'pct-badge badge-amber'; $bar = '#EF9F27'; }
            else                 { $cls = 'pct-badge badge-red';   $bar = '#E24B4A'; }
            $initials = strtoupper(substr($r['user_name'] ?? '?', 0, 1));
            $date     = !empty($r['submitted_on']) ? date('d M Y', strtotime($r['submitted_on'])) : '—';
          ?>
          <tr>
            <td style="font-size:12px;color:#9b9b9a;font-weight:500;">#<?php echo $r['id']; ?></td>
            <td>
              <div class="user-cell">
                <div class="user-avatar"><?php echo $initials; ?></div>
                <span style="font-weight:500;"><?php echo htmlspecialchars($r['user_name'] ?? '—'); ?></span>
              </div>
            </td>
            <td>
              <span class="subject-chip">
                <i class="ti ti-book" style="font-size:11px;"></i>
                <?php echo htmlspecialchars($r['subject_name'] ?? '—'); ?>
              </span>
            </td>
            <td>
              <span style="font-weight:500;"><?php echo $r['score']; ?></span>
              <span style="color:#9b9b9a;"> / <?php echo $r['total_ques']; ?></span>
            </td>
            <td>
              <span class="<?php echo $cls; ?>"><?php echo $pct; ?>%</span>
              <div class="mini-bar-wrap"><div class="mini-bar-fill" style="width:<?php echo $pct; ?>%;background:<?php echo $bar; ?>;"></div></div>
            </td>
            <td style="font-size:12px;color:#6b6b6a;"><?php echo $date; ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <?php else: ?>
        <div class="empty-state">
          <i class="ti ti-clipboard-off"></i>
          <?php echo ($search || $filter_subject > 0) ? "No results match your filters." : "No quiz results yet."; ?>
        </div>
      <?php endif; ?>
    </div>
  </main>
</div>
</body>
</html>